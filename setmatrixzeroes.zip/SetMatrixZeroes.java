import java.util.*;
class SetMatrixZeroes{
    public static void main(String args[]){
        Scanner sc = new Scanner(System.in);
        int m = sc.nextInt();
        int n = sc.nextInt();
        int mat[][] = new int[m][n];
        for(int i=0;i<m;i++){
            for(int j=0;j<n;j++){
                mat[i][j] = sc.nextInt();
            }
        }
        boolean firstrow =  false;
        boolean firstcol =  false;
        
        // check if firstrow has zeeroes and break out of loop if yes;
        
        for(int i=0;i<m;i++){
            for(int j=0;j<n;j++){
                if(mat[0][j] == 0){
                    firstrow = true;
                    break;
                }
            }
        }
    // check if firstcol has zeeroes and break out of loop if yes; 
    
   for(int i=0;i<m;i++){
       for(int j=0;j<n;j++){
           if(mat[i][0] == 0){
               firstcol = true;
               break;
           }
       }
   }
   
   for(int i=1;i<m;i++){
       for(int j=1;j<n;j++){
           if(mat[i][j]==0){
               mat[0][j] = 0;
               mat[i][0] =  0;
           }
       }
   }
   
   for(int i=1;i<m;i++){
       for(int j=1;j<n;j++){
           if(mat[i][0] == 0  || mat[j][0] == 0){
               mat[i][j] = 0;
           }
       }
   }
   
   if(firstrow){
       for(int j=0;j<n;j++){
           mat[0][j] = 0;
       }
   }
   if(firstcol){
       for(int i=0;i<m;i++){
           mat[i][0] = 0;
       }
   }
 
 for(int i=0;i<m;i++){
     for(int j=0;j<n;j++){
         System.out.print(mat[i][j]+" ");
     }
     System.out.println();
 }
   
        
    }
}